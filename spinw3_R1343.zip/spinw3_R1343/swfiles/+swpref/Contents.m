% The SWPREF library handles the permanent settings of the SpinW objects
% that persist during a single Matlab session. It is different from the
% Matlab built-in preferences, as it resets all settings to factory default
% after every restart of Matlab.
%
% Files
%   getpref - returns SpinW global preferences
%   pref    - returns SpinW global preferences
%   setpref - sets SpinW global preferences

% $Name: SpinW$ ($Version: 3.0$)
% $Author: S. Toth$ ($Contact: sandor.toth@psi.ch$)
% $Revision: 1343 $ ($Date: 08-Feb-2017 $)
% $License: GNU GENERAL PUBLIC LICENSE$

