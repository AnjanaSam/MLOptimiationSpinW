function rootdir = sw_rootdir()
% gives the path to the SpinW code
%
% rootdir = SW_ROOTDIR()
%
% See also SW.
%

% $Name: SpinW$ ($Version: 3.0$)
% $Author: S. Toth$ ($Contact: sandor.toth@psi.ch$)
% $Revision: 1343 $ ($Date: 08-Feb-2017 $)
% $License: GNU GENERAL PUBLIC LICENSE$

rootdir = mfilename('fullpath');
idx     = strfind(rootdir,filesep);
rootdir = rootdir(1:idx(end-1));

end