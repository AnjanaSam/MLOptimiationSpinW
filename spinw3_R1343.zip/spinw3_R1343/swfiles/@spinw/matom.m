function mAtomList = matom(obj)
% generates all magnetic atoms in the unit cell
%
% Same as spinw.atom, but only lists the magnetic atoms, which has non-zero
% spin.
%
% See also SPINW.ATOM.
%

% $Name: SpinW$ ($Version: 3.0$)
% $Author: S. Toth$ ($Contact: sandor.toth@psi.ch$)
% $Revision: 1343 $ ($Date: 08-Feb-2017 $)
% $License: GNU GENERAL PUBLIC LICENSE$

if isempty(obj.cache.matom)
    atomList      = obj.atom;
    
    mAtomList.r   = atomList.r(:,atomList.mag==1);
    mAtomList.idx = atomList.idx(:,atomList.mag==1);
    mAtomList.S   = obj.unit_cell.S(mAtomList.idx);
    
    obj.cache.matom = mAtomList;
    
    % add listener to lattice and unit_cell fields
    obj.addlistenermulti(1);
else
    mAtomList = obj.cache.matom;
end

end