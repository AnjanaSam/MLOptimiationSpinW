function verInfo = version(obj)
% returns the version of SpinW used to create the object

% $Name: SpinW$ ($Version: 3.0$)
% $Author: S. Toth$ ($Contact: sandor.toth@psi.ch$)
% $Revision: 1343 $ ($Date: 08-Feb-2017 $)
% $License: GNU GENERAL PUBLIC LICENSE$

verInfo = obj.ver;

end