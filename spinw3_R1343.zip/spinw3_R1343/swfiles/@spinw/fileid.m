function fidOut = fileid(obj,fid)
% determines where the text out is written
%
% FILEID(obj,fid)
%
% Determines the text output of all sw class methods. Default
% is 1, where all output is printed onto the MATLAB Command
% Window.
%
% fidOut = FILEID(obj)
%
% Outputs the stored fileID value.
%
% See also SPINW, SPINW.DISPLAY.
%

% $Name: SpinW$ ($Version: 3.0$)
% $Author: S. Toth$ ($Contact: sandor.toth@psi.ch$)
% $Revision: 1343 $ ($Date: 08-Feb-2017 $)
% $License: GNU GENERAL PUBLIC LICENSE$

if nargin > 1
    obj.fid = fid;
    return
end

fidOut = obj.fid;

end