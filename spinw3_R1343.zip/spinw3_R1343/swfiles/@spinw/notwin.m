function varargout = notwin(obj)
% removes any twin added to the spinw object
%
% NOTWIN(obj)
%
% The function keeps only the original twin.
%

% $Name: SpinW$ ($Version: 3.0$)
% $Author: S. Toth$ ($Contact: sandor.toth@psi.ch$)
% $Revision: 1343 $ ($Date: 08-Feb-2017 $)
% $License: GNU GENERAL PUBLIC LICENSE$

obj.twin.vol = 1;
obj.twin.rotc = eye(3);

if nargout >0
    varargout{1} = obj;
end

end