function varargout = temperature(obj,varargin)
% get/set stored temperature value
%
% TEMPERATURE(obj, T)
%
% If T is defined, it sets the temperature stored in obj object
% to T, where T is scalar. The units of temerature is
% determined by the sw.unit.kB value, default is Kelvin.
%
% T = TEMPERATURE(obj)
%
% The function returns the current temperature value stored in
% obj.
%

% $Name: SpinW$ ($Version: 3.0$)
% $Author: S. Toth$ ($Contact: sandor.toth@psi.ch$)
% $Revision: 1343 $ ($Date: 08-Feb-2017 $)
% $License: GNU GENERAL PUBLIC LICENSE$

if nargin == 1
    varargout{1} = obj.single_ion.T;
elseif nargin == 2
    T = varargin{1};
    if numel(T) == 1
        obj.single_ion.T = T;
    else
        error('sw:temperature:ArraySize','Input temperature has to be scalar!');
    end
    if nargout > 0
        varargout{1} = obj;
    end
end

end