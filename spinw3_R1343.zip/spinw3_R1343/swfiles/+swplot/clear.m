function clear(varargin)
% clear swplot figure
%
% SWPLOT.CLEAR(hFigure)
%
% clears swplot figure correspondign to hFigure handle
%
% SWPLOT.CLEAR
%
% clears the active swplot figure

% $Name: SpinW$ ($Version: 3.0$)
% $Author: S. Toth$ ($Contact: sandor.toth@psi.ch$)
% $Revision: 1343 $ ($Date: 08-Feb-2017 $)
% $License: GNU GENERAL PUBLIC LICENSE$

swplot.delete(varargin{:},0)

end