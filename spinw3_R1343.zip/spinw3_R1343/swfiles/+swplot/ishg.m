function ishg = ishg(hFigure)
% does the swplot figure uses hgtransform
%
% ishg = SWPLOT.ISHG({hFigure})
%
% Input:
%
% hFigure       Handle of the swplot figure. Default is the selected
%               figure.
%

% $Name: SpinW$ ($Version: 3.0$)
% $Author: S. Toth$ ($Contact: sandor.toth@psi.ch$)
% $Revision: 1343 $ ($Date: 08-Feb-2017 $)
% $License: GNU GENERAL PUBLIC LICENSE$

if nargin == 0
    hFigure = swplot.activefigure;
end

ishg = true(1,numel(hFigure));

for ii = 1:numel(hFigure)
    ishg(ii) = ~isempty(getappdata(hFigure(ii),'h'));
end

end