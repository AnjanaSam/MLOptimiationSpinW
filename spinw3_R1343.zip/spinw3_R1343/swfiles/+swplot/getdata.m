function data = getdata(varargin)
% gets the data stored in an swplot figure
%
% data = SWPLOT.GETDATA({hFigure},{field}
%
% Input:
%
% hFigure       Handle of the swplot figure. Default is the active figure.
% field         String, determined the stored field name. If omitted, all
%               stored data are returned.
%
% See also GETAPPDATA.
%

% $Name: SpinW$ ($Version: 3.0$)
% $Author: S. Toth$ ($Contact: sandor.toth@psi.ch$)
% $Revision: 1343 $ ($Date: 08-Feb-2017 $)
% $License: GNU GENERAL PUBLIC LICENSE$

if nargin == 0
    hFigure = swplot.activefigure;
    arg = {hFigure};
elseif nargin == 1 && ischar(varargin{1})
    hFigure = swplot.activefigure;
    arg = {hFigure varargin{1}};
elseif nargin == 1
    arg = {gcf varargin{1}};
else
    arg = varargin;
end

data = getappdata(arg{:});

end