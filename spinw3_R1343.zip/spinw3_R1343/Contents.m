% SpinW
% Version 3.0 (R1343) 08-Feb-2017
%